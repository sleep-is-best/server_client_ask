﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
// using WebCam_Capture; // تم تعليق المكتبة القديمة
using AForge.Video;
using AForge.Video.DirectShow;

namespace server
{
    public partial class server : Form
    {
        private TcpListener servers;
        private TcpClient client;
        private Thread listenThread;
        private Thread readThread;
        // WebCamCapture wep; // تم تعليق الكائن القديم

        // كائنات مكتبة AForge
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;

        private void StartListening()
        {
            try
            {
                servers = new TcpListener(IPAddress.Any, 5050);
                servers.Start();

                // الانتظار لحين قبول اتصال من العميل (هذه الدالة تحجب الخيط الفرعي فقط ولا تجمد الفورم)
                client = servers.AcceptTcpClient();

                // عند نجاح الاتصال، نعرض الرسالة على واجهة المستخدم الرئيسية باستخدام Invoke
                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show("تم الاتصال بنجاح!", "إشعار", MessageBoxButtons.OK, MessageBoxIcon.Information);
                });
                // 2. فور قبول الاتصال، نبدأ خيط القراءة المستمرة تلقائياً
                readThread = new Thread(ReadData);
                readThread.IsBackground = true;
                readThread.Start();
            }
            catch (Exception ex)
            {
                // في حال إغلاق السيرفر بشكل طبيعي عند الخروج لا نعرض خطأ
                //if (servers != null && !servers.Pending()) return;

                this.Invoke((MethodInvoker)delegate
                {
                    MessageBox.Show("حدث خطأ أثناء الاستماع:\n" + ex.Message, "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                });
            }
        }
        private void ReadData()
        {
            while (true)
            {
                try
                {
                    byte[] buffer = new byte[999999]; // مصفوفة الاستقبال
                    int receivedBytes = client.Client.Receive(buffer);

                    // إذا كانت البايتات المستقبلة 0 فهذا يعني أن العميل أغلق الاتصال
                    if (receivedBytes == 0) break;

                    // 1. استخراج بايت التحديد الأول (1 = صورة، 2 = نص)
                    byte dataType = buffer[0];

                    // 2. نسخ البيانات الفعلية بعد استبعاد بايت التحديد
                    byte[] actualData = new byte[receivedBytes - 1];
                    Array.Copy(buffer, 1, actualData, 0, receivedBytes - 1);

                    // 3. التوجيه بناءً على نوع البيانات
                    if (dataType == 1) // 🖼️ صورة
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            using (MemoryStream streamer = new MemoryStream(actualData))
                            {
                                // تنظيف الصورة القديمة من الذاكرة إذا وجدت
                                if (pictureBox1.Image != null)
                                {
                                    pictureBox1.Image.Dispose();
                                }
                                pictureBox1.Image = Image.FromStream(streamer);
                            }
                        });
                    }
                    else if (dataType == 2) // 📝 نص
                    {
                        string message = Encoding.UTF8.GetString(actualData);
                        this.Invoke((MethodInvoker)delegate
                        {
                            textBox1.Text = message;
                        });
                    }
                    else if (dataType == 3) // 📄 ملف مستندات (PDF / Word / TXT / إلخ)
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            using (SaveFileDialog sfd = new SaveFileDialog())
                            {
                                sfd.Title = "حدد مكان وتنسيق حفظ الملف المستلم من السيرفر";

                                // تحديد صيغ الحفظ المتاحة مع إمكانية حفظ أي نوع
                                sfd.Filter = "ملفات PDF (*.pdf)|*.pdf|ملفات Word (*.docx)|*.docx|ملفات نصية (*.txt)|*.txt|جميع الملفات (*.*)|*.*";
                                sfd.FilterIndex = 1; // الافتراضي PDF
                                sfd.RestoreDirectory = true;

                                // فتح نافذة اختيار مكان الحفظ وحفظ الملف
                                if (sfd.ShowDialog() == DialogResult.OK)
                                {
                                    try
                                    {
                                        File.WriteAllBytes(sfd.FileName, actualData);
                                        MessageBox.Show("تم حفظ الملف بنجاح في المكان المحدد:\n" + sfd.FileName,
                                                        "نجاح الحفظ", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        textBox2.Text = sfd.FileName;                           // المسار كامل
                                        textBox3.Text = Path.GetFileName(sfd.FileName);          // اسم الملف مع الامتداد
                                        textBox4.Text = Path.GetExtension(sfd.FileName).ToLower();

                                        textBox5.Text = File.ReadAllText(sfd.FileName, Encoding.UTF8);
                                    }
                                    catch (Exception ex)
                                    {
                                        MessageBox.Show("حدث خطأ أثناء حفظ الملف:\n" + ex.Message,
                                                        "خطأ حفظ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    }
                                }
                            }

                        });
                    }
                    else if (dataType == 4) // بث الكاميرا القادم من السيرفر
                    {
                        this.Invoke((MethodInvoker)delegate
                        {
                            using (MemoryStream streamer = new MemoryStream(actualData))
                            {
                                if (pictureBox2.Image != null)
                                {
                                    pictureBox2.Image.Dispose();
                                }
                                pictureBox2.Image = Image.FromStream(streamer);
                            }
                        });
                    }
                }
                catch
                {
                    // عند حدوث خطأ أو انقطاع المفاجئ للشبكة نخرج من حلقة القراءة
                    break;
                }
            }
        }
        public server()
        {
            /* 
            wep = new WebCamCapture();
            wep.TimeToCapture_milliseconds = 100;
            wep.ImageCaptured += aa;
            */

            //pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;

            // إعداد أجهزة الكاميرا المتاحة باستخدام AForge
            videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            if (videoDevices.Count > 0)
            {
                videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                videoSource.NewFrame += videoSource_NewFrame;
            }

            InitializeComponent();
        }

        private void server_Load(object sender, EventArgs e)
        {
            // بدء خيط الاستماع تلقائياً عند تحميل الفورم
            listenThread = new Thread(StartListening);
            listenThread.IsBackground = true; // لضمان إغلاق الخيط تلقائياً عند إغلاق التطبيق
            listenThread.Start();
            //wep = new WebCamCapture();
            //wep.ImageCaptured += aa;

        }

        /* 
        private void aa(object source, WebcamEventArgs e)
        {
            //pictureBox2.Image = e.WebCamImage;
            Bitmap f = new Bitmap(e.WebCamImage);
            pictureBox2.Image = f;
        }
        */

        private void videoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            Bitmap bitmap = (Bitmap)eventArgs.Frame.Clone();
            this.Invoke((MethodInvoker)delegate
            {
                if (pictureBox2.Image != null) pictureBox2.Image.Dispose();
                pictureBox2.Image = (Bitmap)bitmap.Clone();
            });
            // إذا كان الاتصال قائماً، يتم إرسال الإطار إلى السيرفر ليظهر في pictureBox2 لديه
            if (client != null && client.Connected)
            {
                try
                {
                    using (MemoryStream ms = new MemoryStream())
                    {
                        bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                        byte[] frameBytes = ms.ToArray();

                        // إنشاء طرد بالمعرف 4 للبث المباشر
                        byte[] package = new byte[frameBytes.Length + 1];
                        package[0] = 4; // النوع 4 مخصص للبث
                        Array.Copy(frameBytes, 0, package, 1, frameBytes.Length);

                        client.Client.Send(package);
                    }
                }
                catch
                {
                    // تجاهل الأخطاء العابرة أثناء الإرسال لمنع توقف الكاميرا
                }
            }
        }

        private void server_FormClosing(object sender, FormClosingEventArgs e)
        {
            // إغلاق الكاميرا الخاصة بـ AForge عند إغلاق التطبيق
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.WaitForStop();
            }

            // إغلاق السيرفر والعميل بنظافة عند إغلاق الفورم
            try
            {
                if (client != null)
                    client.Close();

                if (servers != null)
                    servers.Stop();

                if (listenThread != null && listenThread.IsAlive)
                    listenThread.Abort();

                if (readThread != null && readThread.IsAlive)
                {
                    readThread.Abort();
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
        OpenFileDialog op;
        private void button1_Click(object sender, EventArgs e)
        {

            // 1. إعداد منتقي الملفات ليدعم الصور، المستندات، والنصوص
            op = new OpenFileDialog();
            op.Title = "اختر ملفاً للإرسال";

            if (op.ShowDialog() == DialogResult.OK)
            {
                string filePath = op.FileName;
                string extension = Path.GetExtension(filePath).ToLower();

                // تعبئة خانات المسار والاسم والامتداد (كما في كودك القديم)
                textBox2.Text = filePath;                           // المسار كامل
                textBox3.Text = Path.GetFileName(filePath);          // اسم الملف مع الامتداد
                textBox4.Text = extension;                          // الامتداد فقط (.png / .txt / .pdf)

                // 2. الفحص الذكي ونقل المحتوى/العرض بناءً على نوع الملف
                if (extension == ".png" || extension == ".jpg" || extension == ".jpeg")
                {
                    // إذا كان صورة: نعرضها في PictureBox
                    pictureBox1.Image = Image.FromFile(filePath);
                    textBox5.Text = ""; // تفريغ النص
                }
                else if (extension == ".txt")
                {
                    // إذا كان ملف نصي: نقرأ محتواه ونعرضه في textBox7
                    textBox5.Text = File.ReadAllText(filePath, Encoding.UTF8);
                    if (pictureBox1.Image != null) pictureBox1.Image = null; // إزالة الصورة إن وجدت
                }
                else if (extension == ".pdf" || extension == ".doc" || extension == ".docx")
                {
                    // إذا كان ملف مستندات (PDF / Word): الملفات الثنائية لا تُقرأ كنص عادي
                    // نكتفي بتحديد المسار ونقرأ البايتات فقط عند الإرسال
                    textBox5.Text = File.ReadAllText(filePath, Encoding.UTF8);

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. الاحتياط الأول: التأكد من أن الاتصال بالعميل قائم ومفعل
                if (client == null || !client.Connected)
                {
                    MessageBox.Show("عذراً، لا يوجد عميل متصل حالياً!", "تنبيه", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // 2. التحقق من مصدر البيانات المراد إرسالها بناءً على الامتداد الموجود في textBox6
                string extension = textBox4.Text.ToLower();
                string filePath = textBox2.Text;

                byte[] package; // المصفوفة النهائية التي ستُرسل وتحتوي على بايت التحديد

                if (extension == ".png" || extension == ".jpg" || extension == ".jpeg")
                {
                    // === الحالة الأولى: إرسال صورة ===
                    if (pictureBox1.Image == null)
                    {
                        MessageBox.Show("لا توجد صورة محددة للإرسال!", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // قراءة الصورة كبايتات مباشرة من المسار (أدق وأسلم من قراءتها من PictureBox)
                    byte[] imageBytes = File.ReadAllBytes(filePath);

                    // إنشاء حزمة جديدة بزيادة بايت واحد في المقدمة (بايت رقم 1 يعني صورة)
                    package = new byte[imageBytes.Length + 1];
                    package[0] = 1; // 1 -> يمثل نوع البيانات "صورة"
                    Array.Copy(imageBytes, 0, package, 1, imageBytes.Length);
                }
                else if (extension == ".pdf" || extension == ".doc" || extension == ".docx")
                {
                    // === الحالة الثانية: إرسال مستند (PDF أو Word) ===
                    if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
                    {
                        MessageBox.Show("ملف المستند غير موجود أو لم يتم تحديده!", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    byte[] fileBytes = File.ReadAllBytes(filePath);

                    // إنشاء حزمة جديدة (بايت رقم 3 يمثل ملف مستند عام)
                    package = new byte[fileBytes.Length + 1];
                    package[0] = 3; // 3 -> يمثل نوع البيانات "ملف/مستند"
                    Array.Copy(fileBytes, 0, package, 1, fileBytes.Length);
                }
                else
                {
                    // === الحالة الثالثة: إرسال نص (افتراضي أو ملف .txt) ===
                    string textContent = textBox1.Text;
                    if (string.IsNullOrEmpty(textContent))
                    {
                        MessageBox.Show("لا توجد بيانات نصية للإرسال!", "خطأ", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    byte[] textBytes = Encoding.UTF8.GetBytes(textContent);

                    // إنشاء حزمة جديدة (بايت رقم 2 يمثل نص)
                    package = new byte[textBytes.Length + 1];
                    package[0] = 2; // 2 -> يمثل نوع البيانات "نص"
                    Array.Copy(textBytes, 0, package, 1, textBytes.Length);
                }

                // 3. عملية الإرسال الفعلية عبر السوكت
                client.Client.Send(package);

                MessageBox.Show("تم إرسال البيانات بنجاح!", "عملية ناجحة", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("حدث خطأ أثناء الإرسال:\n" + ex.Message, "خطأ شبكة", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                // 4. التفريغ بعد الإرسال (Clean Up): تفريغ الحقول والصور لمنع بقائها معلقة
                textBox2.Text = "";
                textBox3.Text = "";
                textBox4.Text = "";
                textBox5.Text = "";

                if (pictureBox1.Image != null)
                {
                    pictureBox1.Image.Dispose(); // تنظيف الذاكرة للصورة القديمة
                    pictureBox1.Image = null;
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // wep.Start(100); // تم تعليق التشغيل القديم

            // بدء التلتقيط عبر AForge
            if (videoSource != null && !videoSource.IsRunning)
            {
                videoSource.Start();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox1.Image = null;
                if (pictureBox2 != null)
                {
                    if (pictureBox1.Image != null)
                    {
                        pictureBox1.Image = null; pictureBox1.Image.Dispose();

                    }
                    pictureBox1.Image = pictureBox2.Image;
                }
                else
                {
                    MessageBox.Show("no image in");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }

}